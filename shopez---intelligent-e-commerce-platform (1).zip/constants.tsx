
import { Product } from './types';

export const CATEGORIES = ['All', 'Electronics', 'Fashion', 'Home', 'Beauty', 'Sports'];

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Nebula Pro Headphones',
    category: 'Electronics',
    price: 299.99,
    originalPrice: 349.99,
    description: 'Immersive noise-cancelling headphones with spatial audio and 40-hour battery life. Perfect for audiophiles and travelers.',
    image: 'https://picsum.photos/seed/nebula/600/600',
    rating: 4.8,
    reviews: 1240
  },
  {
    id: '2',
    name: 'Lunar Glide Sneakers',
    category: 'Fashion',
    price: 129.50,
    originalPrice: 159.00,
    description: 'Ultra-lightweight running shoes designed for maximum comfort and speed. Feature breathable mesh and responsive cushioning.',
    image: 'https://picsum.photos/seed/shoes/600/600',
    rating: 4.6,
    reviews: 856
  },
  {
    id: '3',
    name: 'Smart Kitchen Hub',
    category: 'Home',
    price: 199.00,
    description: 'The ultimate kitchen assistant. Control appliances, follow recipes, and manage groceries from one sleek touchscreen.',
    image: 'https://picsum.photos/seed/kitchen/600/600',
    rating: 4.7,
    reviews: 432
  },
  {
    id: '4',
    name: 'Zenith OLED 4K Monitor',
    category: 'Electronics',
    price: 549.99,
    originalPrice: 699.99,
    description: 'Professional grade monitor with stunning color accuracy and infinite contrast. Ideal for designers and gamers.',
    image: 'https://picsum.photos/seed/monitor/600/600',
    rating: 4.9,
    reviews: 312
  },
  {
    id: '5',
    name: 'Eco-Luxe Organic Tote',
    category: 'Fashion',
    price: 45.00,
    description: 'Sustainably sourced organic cotton tote. Stylish, durable, and perfect for daily essentials or grocery runs.',
    image: 'https://picsum.photos/seed/tote/600/600',
    rating: 4.5,
    reviews: 156
  },
  {
    id: '6',
    name: 'Aura Skincare Set',
    category: 'Beauty',
    price: 89.00,
    description: 'Premium hydration set featuring hyaluronic acid and botanical extracts for a radiant, glowing complexion.',
    image: 'https://picsum.photos/seed/beauty/600/600',
    rating: 4.4,
    reviews: 289
  },
  {
    id: '7',
    name: 'Titan Power Rack',
    category: 'Sports',
    price: 899.00,
    description: 'Heavy-duty steel power rack for serious strength training at home. Includes pull-up bar and safety spotters.',
    image: 'https://picsum.photos/seed/gym/600/600',
    rating: 4.9,
    reviews: 67
  },
  {
    id: '8',
    name: 'Voyager Smart Watch',
    category: 'Electronics',
    price: 249.00,
    originalPrice: 299.00,
    description: 'Advanced health tracking, GPS, and cellular connectivity in a rugged, elegant titanium frame.',
    image: 'https://picsum.photos/seed/watch/600/600',
    rating: 4.7,
    reviews: 1102
  },
  {
    id: '9',
    name: 'Quantum Tab Ultra',
    category: 'Electronics',
    price: 799.00,
    description: 'The most powerful tablet for creators. Features a stunning 120Hz display and all-day battery life.',
    image: 'https://picsum.photos/seed/tablet/600/600',
    rating: 4.8,
    reviews: 450
  },
  {
    id: '10',
    name: 'Pixel Flow Camera',
    category: 'Electronics',
    price: 1200.00,
    description: 'Mirrorless camera with 8K video capabilities and lightning-fast autofocus for professional photography.',
    image: 'https://picsum.photos/seed/camera/600/600',
    rating: 4.9,
    reviews: 180
  },
  {
    id: '11',
    name: 'Sonic Wave Speaker',
    category: 'Electronics',
    price: 159.00,
    description: 'Portable waterproof speaker with 360-degree sound and deep bass. Perfect for outdoor adventures.',
    image: 'https://picsum.photos/seed/speaker/600/600',
    rating: 4.6,
    reviews: 920
  },
  {
    id: '12',
    name: 'Urban Edge Denim Jacket',
    category: 'Fashion',
    price: 85.00,
    description: 'Classic fit denim jacket with a modern twist. Made from premium recycled cotton for a sustainable style.',
    image: 'https://picsum.photos/seed/denim/600/600',
    rating: 4.7,
    reviews: 340
  },
  {
    id: '13',
    name: 'Silk Breeze Summer Dress',
    category: 'Fashion',
    price: 110.00,
    description: 'Lightweight and elegant silk dress. Designed for comfort during warm summer evenings.',
    image: 'https://picsum.photos/seed/dress/600/600',
    rating: 4.8,
    reviews: 210
  },
  {
    id: '14',
    name: 'Tech-Fit Performance Tee',
    category: 'Fashion',
    price: 35.00,
    description: 'Moisture-wicking athletic tee with four-way stretch. Ideal for high-intensity workouts.',
    image: 'https://picsum.photos/seed/tee/600/600',
    rating: 4.5,
    reviews: 560
  },
  {
    id: '15',
    name: 'Classic Wool Overcoat',
    category: 'Fashion',
    price: 240.00,
    description: 'Timeless wool blend overcoat. Provides superior warmth and a sophisticated silhouette for winter.',
    image: 'https://picsum.photos/seed/coat/600/600',
    rating: 4.9,
    reviews: 125
  },
  {
    id: '16',
    name: 'Minimalist Oak Desk',
    category: 'Home',
    price: 350.00,
    description: 'Clean lines and solid oak construction. The perfect centerpiece for a modern home office.',
    image: 'https://picsum.photos/seed/desk/600/600',
    rating: 4.7,
    reviews: 88
  },
  {
    id: '17',
    name: 'Cloud Comfort Sofa',
    category: 'Home',
    price: 1200.00,
    description: 'Deep-seated modular sofa with memory foam cushions. Experience ultimate relaxation in your living room.',
    image: 'https://picsum.photos/seed/sofa/600/600',
    rating: 4.8,
    reviews: 45
  },
  {
    id: '18',
    name: 'Smart Ambient Lamp',
    category: 'Home',
    price: 75.00,
    description: 'Adjustable color temperature and brightness. Syncs with your music and smart home ecosystem.',
    image: 'https://picsum.photos/seed/lamp/600/600',
    rating: 4.6,
    reviews: 230
  },
  {
    id: '19',
    name: 'Hydro-Pure Water Filter',
    category: 'Home',
    price: 120.00,
    description: 'Multi-stage filtration system for crisp, clean water. Easy to install and eco-friendly.',
    image: 'https://picsum.photos/seed/filter/600/600',
    rating: 4.5,
    reviews: 167
  },
  {
    id: '20',
    name: 'Nordic Coffee Table',
    category: 'Home',
    price: 180.00,
    description: 'Scandinavian inspired design with a functional storage shelf. Crafted from sustainable birch wood.',
    image: 'https://picsum.photos/seed/table/600/600',
    rating: 4.7,
    reviews: 94
  },
  {
    id: '21',
    name: 'Apex Gaming Laptop',
    category: 'Electronics',
    price: 1499.00,
    description: 'High-performance gaming laptop with RTX 4080, 32GB RAM, and a 240Hz QHD display. Dominate any game with ease.',
    image: 'https://picsum.photos/seed/laptop/600/600',
    rating: 4.9,
    reviews: 45
  },
  {
    id: '22',
    name: 'Vision 8K Smart TV',
    category: 'Electronics',
    price: 2499.00,
    description: 'Breathtaking 8K resolution with AI upscaling and cinematic sound. Transform your living room into a theater.',
    image: 'https://picsum.photos/seed/tv/600/600',
    rating: 4.8,
    reviews: 32
  },
  {
    id: '23',
    name: 'Ergo-Lift Massage Chair',
    category: 'Home',
    price: 1899.00,
    description: 'Zero-gravity massage chair with heat therapy and body scanning technology for a personalized spa experience.',
    image: 'https://picsum.photos/seed/massage/600/600',
    rating: 4.7,
    reviews: 18
  },
  {
    id: '24',
    name: 'Velocity Electric Bike',
    category: 'Sports',
    price: 1250.00,
    description: 'Eco-friendly electric bike with a 50-mile range and pedal-assist. Perfect for urban commuting and weekend trails.',
    image: 'https://picsum.photos/seed/ebike/600/600',
    rating: 4.6,
    reviews: 54
  },
  {
    id: '25',
    name: 'Elite Tailored Suit',
    category: 'Fashion',
    price: 650.00,
    description: 'Premium Italian wool suit, custom-tailored for a perfect fit. Exude confidence at any formal event.',
    image: 'https://picsum.photos/seed/suit/600/600',
    rating: 4.9,
    reviews: 28
  },
  {
    id: '26',
    name: 'Heritage Chronograph Watch',
    category: 'Fashion',
    price: 899.00,
    description: 'Exquisite automatic chronograph with sapphire crystal and genuine leather strap. A masterpiece of horology.',
    image: 'https://picsum.photos/seed/luxurywatch/600/600',
    rating: 4.8,
    reviews: 112
  },
  {
    id: '27',
    name: 'Royal Essence Fragrance Set',
    category: 'Beauty',
    price: 550.00,
    description: 'Limited edition luxury fragrance collection featuring rare botanical extracts and a handcrafted crystal bottle.',
    image: 'https://picsum.photos/seed/perfume/600/600',
    rating: 4.7,
    reviews: 89
  },
  {
    id: '28',
    name: 'Smart Chef Refrigerator',
    category: 'Home',
    price: 3200.00,
    description: 'Next-gen refrigerator with built-in screen, internal cameras, and precise climate control for maximum freshness.',
    image: 'https://picsum.photos/seed/fridge/600/600',
    rating: 4.9,
    reviews: 21
  },
  {
    id: '29',
    name: 'Pro-Series Golf Set',
    category: 'Sports',
    price: 1100.00,
    description: 'Complete professional golf club set with titanium drivers and carbon fiber shafts. Engineered for distance and accuracy.',
    image: 'https://picsum.photos/seed/golf/600/600',
    rating: 4.8,
    reviews: 37
  },
  {
    id: '30',
    name: 'SoundSphere Home Theater',
    category: 'Electronics',
    price: 799.00,
    description: 'Wireless 7.1 surround sound system with Dolby Atmos support. Crystal clear audio for movies and music.',
    image: 'https://picsum.photos/seed/theater/600/600',
    rating: 4.7,
    reviews: 156
  },
  {
    id: '31',
    name: 'PureAir Pro Purifier',
    category: 'Home',
    price: 520.00,
    description: 'Industrial-grade air purifier with HEPA-14 filtration and real-time air quality monitoring. Breathe pure.',
    image: 'https://picsum.photos/seed/purifier/600/600',
    rating: 4.6,
    reviews: 210
  },
  {
    id: '32',
    name: 'Signature Leather Jacket',
    category: 'Fashion',
    price: 580.00,
    description: 'Handcrafted premium lambskin leather jacket. Timeless design that gets better with age.',
    image: 'https://picsum.photos/seed/leather/600/600',
    rating: 4.8,
    reviews: 76
  }
];
